-- EXPLAIN Query: View execution plan
EXPLAIN SELECT * FROM employees WHERE salary > 50000;
