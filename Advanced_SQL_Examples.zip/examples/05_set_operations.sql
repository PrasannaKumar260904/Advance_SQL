-- Set Operation: INTERSECT emp1 and emp2
SELECT name FROM emp1
INTERSECT
SELECT name FROM emp2;
